$(function()
{
	$("#dataForm").submit(function(event)
	{
		event.preventDefault();
		$("#dataForm").ajaxSubmit(_options);
	});
}); 

$tecamo.validCallBack = function()
{
	return true;
};
$(function(){
	$dswork.beforeSubmit = function(){
		var rtn = $dswork.validCallBack();
		if(!rtn){return false;}
		if(!$jskey.validator.Validate("dataForm", $dswork.validValue || 3)){
			return false;
		}
		return true;
	};
	jQuery("#dataFormSave").click(function(){
		if($dswork.beforeSubmit()){
			if(confirm("确定保存吗？")){
				if($dswork.doAjax){
					$("#dataForm").ajaxSubmit(_options);
				}
				else{
					$("#dataForm").submit();
				}
				return true;
			}
		}
		return false;
	});
	try{$(".form_title").css("width", "20%");}catch(e){}
});
$dswork.validCallBack = function()
{
	return true;
};
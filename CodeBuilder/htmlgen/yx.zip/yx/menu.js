﻿var treedata = [
{id:100, name:'Demo项目', img:"", imgOpen:"", url:"", items:[
	{id:101,name:'Demo列表', img:"", imgOpen:"", url:'../yx/manage/demo/get.html', items:[]}
	,{id:102,name:'Demo添加', img:"", imgOpen:"", url:'../yx/manage/demo/edit.html', items:[]}
]}
,
{id:300, name:'普通管理', img:"", imgOpen:"", url:"", items:[
	{id:301,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:302,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:303,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:304,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:305,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:306,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:307,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:308,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:309,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:310,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:311,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:312,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:313,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:314,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:315,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:316,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:317,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:318,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:319,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
	{id:320,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]}
]}
,
{id:400, name:'树状管理', img:"", imgOpen:"", url:"", items:[
	{id:1300, name:'样例管理', img:"", imgOpen:"", url:"", items:[
		{id:1301,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:1302,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:1303,name:'样例菜单', img:"default.gif", imgOpen:"", url:'#1', items:[]},
		{id:1304,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]}
	]}
	,
	{id:2300, name:'样例管理', img:"", imgOpen:"default.gif", url:"", items:[
		{id:2301,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2302,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2303,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2304,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2305,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2306,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2307,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2308,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2309,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2310,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2311,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2312,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2313,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2314,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2315,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2316,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2317,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2318,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2319,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:2320,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]}
	]}
	,
	{id:3300, name:'样例管理', img:"default.gif", imgOpen:"", url:"", items:[
		{id:3301,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:3302,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:3303,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:3304,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]}
	]}
	,
	{id:4300, name:'样例管理', img:"default.gif", imgOpen:"default.gif", url:"", items:[
		{id:4301,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:4302,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:4303,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]},
		{id:4304,name:'样例菜单', img:"", imgOpen:"", url:'#1', items:[]}
	]}
]}
];
